Examples
========

Here you will find examples and tutorials on how to use NLP in Danish.


The `benchmarks` folder contains scripts to reproduce the benchmark results reported in our [documentation](https://danlp-alexandra.readthedocs.io/en/latest/tasks.html). 

The `tutorials` folder contains jupyter notebook tutorials on how to use Danish NLP tools (including the danlp package but not only). 
​