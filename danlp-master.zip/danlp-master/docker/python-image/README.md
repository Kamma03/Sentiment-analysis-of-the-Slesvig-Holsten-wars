DaNLP Python Image
============================
This Docker image is build on top of the [Python Docker Image](https://hub.docker.com/_/python).

The image build can be found on [Docker Hub](https://hub.docker.com/r/alexandrainst/danlp) and you can pull the image 

```bash
docker pull alexandrainst/danlp
``` 