Tasks
=====


.. toctree::
   :maxdepth: 1

   docs/tasks/embeddings.md
   docs/tasks/pos.md
   docs/tasks/ner.md
   docs/tasks/dependency.md
   docs/tasks/sentiment_analysis.md